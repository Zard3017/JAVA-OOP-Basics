
package VarTest;


public class Vartest {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int iNum=25;
        char cVal='B';
        boolean bVal=true;
        
        System.out.println(iNum);
        System.out.println(cVal);
        System.out.println(bVal);
    }
    
}


